
const express = require("express");
const { getCached, clearCache } = require("../services/cacheService");

const router = express.Router();

async function loadSampleData() {
  await new Promise((resolve) => setTimeout(resolve, 1000));

  return {
    title: "Advanced Server-Side Functionality",
    internship: "Cognifyz Technologies",
    task: "Level 4 - Task 8",
    features: [
      "Request middleware",
      "Background jobs",
      "Redis caching"
    ],
    generatedAt: new Date().toISOString()
  };
}

router.get("/", async (req, res, next) => {
  try {
    const result = await getCached(
      "demo:server-data",
      loadSampleData
    );

    res.json({
      success: true,
      cache: result.cache,
      ttlSeconds: Number(process.env.CACHE_TTL) || 60,
      data: result.data
    });
  } catch (error) {
    next(error);
  }
});

router.delete("/cache", async (req, res, next) => {
  try {
    await clearCache("demo:server-data");

    res.json({
      success: true,
      message: "Sample data cache cleared successfully"
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
