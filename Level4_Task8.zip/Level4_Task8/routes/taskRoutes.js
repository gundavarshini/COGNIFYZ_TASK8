
const express = require("express");
const { randomUUID } = require("crypto");
const taskQueue = require("../queues/taskQueue");

const router = express.Router();

router.post("/", async (req, res, next) => {
  try {
    const taskName =
      typeof req.body.taskName === "string"
        ? req.body.taskName.trim()
        : "";

    if (!taskName || taskName.length > 100) {
      return res.status(400).json({
        success: false,
        message: "taskName is required and must be under 100 characters"
      });
    }

    const job = await taskQueue.add(
      "process-request",
      {
        taskName,
        payload: req.body.payload ?? {},
        requestedAt: new Date().toISOString()
      },
      {
        jobId: randomUUID()
      }
    );

    res.status(202).json({
      success: true,
      message: "Background task queued successfully",
      jobId: job.id,
      statusUrl: `/api/tasks/${job.id}`
    });
  } catch (error) {
    next(error);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    const job = await taskQueue.getJob(req.params.id);

    if (!job) {
      return res.status(404).json({
        success: false,
        message: "Task not found"
      });
    }

    const state = await job.getState();

    res.json({
      success: true,
      jobId: job.id,
      taskName: job.name,
      status: state,
      result: state === "completed" ? job.returnvalue : null,
      error: state === "failed" ? job.failedReason : null
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
