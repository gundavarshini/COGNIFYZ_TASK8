
const $ = (selector) => document.querySelector(selector);

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      ...(options.body
        ? { "Content-Type": "application/json" }
        : {}),
      ...options.headers
    }
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
}

function showResult(element, data) {
  element.textContent = JSON.stringify(data, null, 2);
}

function showError(element, error) {
  element.textContent = JSON.stringify({
    success: false,
    message: error.message
  }, null, 2);
}

async function checkHealth() {
  const status = $("#serverStatus");
  const dot = $("#statusDot");

  try {
    const data = await apiRequest("/api/health");

    status.textContent = "Server and Redis connected";
    dot.className = "status-dot online";
    showResult($("#healthResult"), data);
  } catch (error) {
    status.textContent = "Server unavailable";
    dot.className = "status-dot offline";
    showError($("#healthResult"), error);
  }
}

$("#healthBtn").addEventListener("click", checkHealth);
$("#refreshBtn").addEventListener("click", checkHealth);

$("#fetchDataBtn").addEventListener("click", async () => {
  const button = $("#fetchDataBtn");
  const output = $("#cacheResult");

  button.disabled = true;
  output.textContent = "Fetching data...";

  try {
    const data = await apiRequest("/api/data");
    showResult(output, data);
  } catch (error) {
    showError(output, error);
  } finally {
    button.disabled = false;
  }
});

$("#clearCacheBtn").addEventListener("click", async () => {
  const button = $("#clearCacheBtn");
  const output = $("#cacheResult");

  button.disabled = true;

  try {
    const data = await apiRequest("/api/data/cache", {
      method: "DELETE"
    });

    showResult(output, data);
  } catch (error) {
    showError(output, error);
  } finally {
    button.disabled = false;
  }
});

$("#taskForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  const button = $("#submitTaskBtn");
  const output = $("#taskResult");
  const taskName = $("#taskName").value.trim();
  const description = $("#taskPayload").value.trim();

  if (!taskName) {
    output.textContent = "Please enter a task name.";
    return;
  }

  button.disabled = true;
  output.textContent = "Submitting background task...";

  try {
    const created = await apiRequest("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        taskName,
        payload: { description }
      })
    });

    showResult(output, created);

    const jobId = created.jobId;
    let attempts = 0;
    const maxAttempts = 20;

    async function pollJob() {
      if (attempts >= maxAttempts) {
        output.textContent +=
          "\n\nPolling stopped. Check the job again later.";
        button.disabled = false;
        return;
      }

      attempts++;

      try {
        const job = await apiRequest(
          `/api/tasks/${encodeURIComponent(jobId)}`
        );

        showResult(output, job);

        if (job.status === "completed" ||
            job.status === "failed") {
          button.disabled = false;
          return;
        }

        setTimeout(pollJob, 1000);
      } catch (error) {
        showError(output, error);
        button.disabled = false;
      }
    }

    await pollJob();
  } catch (error) {
    showError(output, error);
    button.disabled = false;
  }
});

// Initial dashboard status check
checkHealth();
