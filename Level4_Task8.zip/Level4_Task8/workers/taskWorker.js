
require("dotenv").config();

const { Worker } = require("bullmq");
const redisConnection = require("../config/redis");

const worker = new Worker(
  "advanced-tasks",
  async (job) => {
    console.log(`Processing job ${job.id}: ${job.name}`);

    // Simulate asynchronous work without blocking the server.
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      jobId: job.id,
      taskName: job.name,
      input: job.data,
      completedAt: new Date().toISOString(),
      message: "Background task completed successfully"
    };

    console.log(`Completed job ${job.id}`);
    return result;
  },
  {
    connection: redisConnection,
    concurrency: 5
  }
);

worker.on("completed", (job) => {
  console.log(`Job ${job.id} completed`);
});

worker.on("failed", (job, error) => {
  console.error(
    `Job ${job?.id || "unknown"} failed:`,
    error.message
  );
});

worker.on("error", (error) => {
  console.error("Worker error:", error.message);
});

async function shutdown() {
  console.log("Shutting down worker...");
  await worker.close();
  await redisConnection.quit();
  process.exit(0);
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
