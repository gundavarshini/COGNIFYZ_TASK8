
function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  const statusCode = err.statusCode || 500;

  console.error("Application error:", {
    requestId: req.requestId,
    message: err.message
  });

  res.status(statusCode).json({
    success: false,
    message:
      statusCode >= 500
        ? "Internal server error"
        : err.message,
    requestId: req.requestId
  });
}

module.exports = errorHandler;
