
function requestLogger(req, res, next) {
  const startTime = Date.now();

  res.on("finish", () => {
    const duration = Date.now() - startTime;

    console.log(
      `[${new Date().toISOString()}]`,
      `ID=${req.requestId || "N/A"}`,
      `${req.method} ${req.originalUrl}`,
      `Status=${res.statusCode}`,
      `Duration=${duration}ms`
    );
  });

  next();
}

module.exports = requestLogger;
