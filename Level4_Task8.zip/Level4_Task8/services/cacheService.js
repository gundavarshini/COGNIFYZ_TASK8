
const redis = require("../config/redis");

const TTL = Math.max(
  1,
  Number(process.env.CACHE_TTL) || 60
);

async function getCached(key, fetchData) {
  const cachedValue = await redis.get(key);

  if (cachedValue !== null) {
    return {
      data: JSON.parse(cachedValue),
      cache: "HIT"
    };
  }

  const data = await fetchData();

  await redis.set(
    key,
    JSON.stringify(data),
    "EX",
    TTL
  );

  return {
    data,
    cache: "MISS"
  };
}

async function clearCache(key) {
  return redis.del(key);
}

module.exports = {
  getCached,
  clearCache
};
