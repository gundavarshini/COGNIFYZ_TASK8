
const { Queue } = require("bullmq");
const redisConnection = require("../config/redis");

const taskQueue = new Queue("advanced-tasks", {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: "exponential",
      delay: 1000
    },
    removeOnComplete: {
      age: 3600,
      count: 500
    },
    removeOnFail: {
      age: 86400
    }
  }
});

module.exports = taskQueue;
