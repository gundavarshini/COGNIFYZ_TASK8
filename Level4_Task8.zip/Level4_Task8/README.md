
# Cognifyz Technologies - Level 4 Task 8
## Advanced Server-Side Functionality

### Overview

This project is developed as part of the **Cognifyz Technologies Full Stack Development Internship – Level 4, Task 8**.

The application demonstrates advanced server-side development using Node.js, Express.js, Redis, and BullMQ. It implements request-processing middleware, asynchronous background jobs, and server-side caching to improve application organization and performance.

### Objectives

- Implement custom middleware for request IDs, logging, and error handling.
- Process background jobs asynchronously using BullMQ and Redis.
- Cache server responses using Redis with configurable expiration.
- Develop REST API endpoints for health monitoring, caching, and job tracking.
- Build a responsive dashboard to interact with backend features.

### Technology Stack

| Technology | Purpose |
|---|---|
| HTML5 | Dashboard structure |
| CSS3 | Responsive user interface |
| JavaScript | Frontend interactions and API requests |
| Node.js | Server-side JavaScript runtime |
| Express.js | REST API routing and middleware |
| Redis | In-memory caching and queue storage |
| BullMQ | Background job processing |
| ioredis | Redis connection management |
| dotenv | Environment variable configuration |
| Git and GitHub | Version control and project hosting |

### Key Features

**1. Request Middleware**
- JSON and URL-encoded request parsing.
- Unique request ID generation.
- HTTP request logging and response timing.
- Centralized error handling.

**2. Background Job Processing**
- Submit jobs through a REST API.
- Process jobs in a separate worker process.
- Track job status and results.
- Configure retry attempts with exponential backoff.

**3. Server-Side Caching**
- Store API response data in Redis.
- Identify cache hits and misses.
- Configure cache expiration using a TTL.
- Invalidate cached data through an API endpoint.

**4. Monitoring Dashboard**
- Check server and Redis connectivity.
- Test caching behavior.
- Submit and monitor background tasks.
- View JSON API responses.

### Project Structure

```text
Level4_Task8/
├── config/
│   └── redis.js
├── middleware/
│   ├── errorHandler.js
│   ├── requestId.js
│   └── requestLogger.js
├── queues/
│   └── taskQueue.js
├── workers/
│   └── taskWorker.js
├── routes/
│   ├── dataRoutes.js
│   └── taskRoutes.js
├── services/
│   └── cacheService.js
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── app.js
│   └── index.html
├── .env.example
├── .gitignore
├── package.json
├── package-lock.json
├── server.js
└── README.md
```

### API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Checks server and Redis connectivity |
| GET | `/api/data` | Retrieves sample data using Redis caching |
| DELETE | `/api/data/cache` | Clears the sample data cache |
| POST | `/api/tasks` | Adds a background task to the queue |
| GET | `/api/tasks/:id` | Retrieves the status and result of a task |

### Installation and Execution

1. Install Node.js and start a Redis server.
2. Clone or download the repository.
3. Install dependencies using `npm install`.
4. Configure the `.env` file.
5. Start the Express server using `npm run dev`.
6. Start the background worker in another terminal using `npm run worker`.
7. Open `http://localhost:5000` in your browser.

### Learning Outcomes

- Understanding Express middleware and request lifecycles.
- Implementing asynchronous background processing.
- Using Redis for caching and queue storage.
- Designing REST APIs with appropriate HTTP status codes.
- Organizing a maintainable Node.js application.

### Internship Information

**Organization:** Cognifyz Technologies  
**Internship:** Full Stack Development Internship  
**Level:** Level 4 – Expert  
**Task:** Task 8 – Advanced Server-Side Functionality

### Future Enhancements

- Add persistent application data storage.
- Implement authentication and role-based access.
- Add automated tests and structured application metrics.
- Replace the demonstration job with a real notification or report-generation workflow.

### License

This project is intended for educational and internship demonstration purposes.
