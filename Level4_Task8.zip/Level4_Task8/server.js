
require("dotenv").config();

const express = require("express");
const path = require("path");

const redis = require("./config/redis");
const requestId = require("./middleware/requestId");
const requestLogger = require("./middleware/requestLogger");
const errorHandler = require("./middleware/errorHandler");

const dataRoutes = require("./routes/dataRoutes");
const taskRoutes = require("./routes/taskRoutes");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

// Built-in middleware
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));

// Custom middleware
app.use(requestId);
app.use(requestLogger);

// Serve the frontend
app.use(express.static(path.join(__dirname, "public")));

// Health endpoint
app.get("/api/health", async (req, res, next) => {
  try {
    await redis.ping();

    res.json({
      success: true,
      message: "Advanced server is running",
      redis: "connected",
      timestamp: new Date().toISOString(),
      requestId: req.requestId
    });
  } catch (error) {
    next(error);
  }
});

// API routes
app.use("/api/data", dataRoutes);
app.use("/api/tasks", taskRoutes);

// Handle unknown API routes
app.use("/api", (req, res) => {
  res.status(404).json({
    success: false,
    message: "API endpoint not found",
    path: req.originalUrl,
    requestId: req.requestId
  });
});

// Centralized error handler must be last
app.use(errorHandler);

const server = app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

async function shutdown() {
  console.log("Shutting down server...");

  server.close(async () => {
    try {
      await redis.quit();
      console.log("Server stopped");
      process.exit(0);
    } catch (error) {
      console.error("Shutdown error:", error.message);
      process.exit(1);
    }
  });
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
